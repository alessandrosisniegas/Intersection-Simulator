#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include "Road.h"
#include <utility>
#include <fstream>

using namespace std;

int main() {
    Road north;
    Road south;
    Road east;
    Road west;
    string Ticks;
    int numTicks;
    unsigned int i;
    unsigned int j;
    unsigned int k = 0;
    ifstream file;
    string userFile;

    cin >> userFile;
    file.open(userFile);
    getline(file, Ticks);
    numTicks = stoi(Ticks);

    vector<string> fileTicks(numTicks);

    for (i = 0; i < numTicks; ++i) {
        getline(file, fileTicks.at(i));
    }

    east.changeLight();
    west.changeLight();
    i = 0;
/*
    while (k < numTicks && i < numTicks) {
        for (i = 0; i < numTicks; ++i) {
            north.changeLight();
            south.changeLight();
            east.changeLight();
            west.changeLight();
            for (j = 0; j < k + 5; ++j) {
                north.carsIn(((fileTicks.at(i)).at(0)) - '0');
                east.carsIn(((fileTicks.at(i)).at(1)) - '0');
                south.carsIn(((fileTicks.at(i)).at(2)) - '0');
                west.carsIn(((fileTicks.at(i)).at(3)) - '0');
                if (north.lightColor() == GREEN) {
                    north.carsOut(1);
                    south.carsOut(1);
                } else {
                    east.carsOut(1);
                    west.carsOut(1);
                }
            }
            ++k;
        }
    }
*/
    for (i = 0; i < numTicks; ++i) {
        north.carsIn(((fileTicks.at(i)).at(0)) - '0');
        east.carsIn(((fileTicks.at(i)).at(1)) - '0');
        south.carsIn(((fileTicks.at(i)).at(2)) - '0');
        west.carsIn(((fileTicks.at(i)).at(3)) - '0');
        if (north.lightColor() == GREEN) {
            north.carsOut(1);
            south.carsOut(1);
        } else {
            east.carsOut(1);
            west.carsOut(1);
        }
        if (i % 5 == 0) {
            north.changeLight();
            south.changeLight();
            east.changeLight();
            west.changeLight();
        }
    }

    cout << "The amount of cars still waiting after " << numTicks << " ticks:" << endl;
    cout << "North: " << north.carsWaiting() << endl;
    cout << "East: " << east.carsWaiting() << endl;
    cout << "South: " << south.carsWaiting() << endl;
    cout << "West: " << west.carsWaiting() << endl;

    cout << "The amount of cars through after " << numTicks << " ticks:" << endl;
    cout << "North: " << north.carsThrough() << endl;
    cout << "East: " << east.carsThrough() << endl;
    cout << "South: " << south.carsThrough() << endl;
    cout << "West: " << west.carsThrough() << endl;

    file.close();

    return 0;
}