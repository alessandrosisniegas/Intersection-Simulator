#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include "Road.h"
#include <utility>

using namespace std;

Road::Road() {
carsInLine = 0;
carsOutLine = 0;
light = RED;
}

int Road::carsWaiting() {
    return carsInLine;
}

int Road::carsThrough() {
    return carsOutLine;
}

void Road::carsIn(int change) {
    carsInLine += change;
}

void Road::carsOut(int change) {
    carsOutLine += change;
}

Color Road::lightColor() {
    return light;
}

void Road::changeLight() {
    if (light == RED) {
        light = GREEN;
    } else {
        light = RED;
    }
}

